# Personal Portfolio👾

This is my personal portfolio and blog page, live at [yunze.li](yunze.li). Information on the site are updated from time to time, usually twice every month.

The site is built with HTML, CSS, JavaScript, and Jquery. Feel free to use this site as inspiration to create your own.

## Credits
This repository contains the work of *Michael Li*. Do not use or reference the contents of this repository without properly crediting its author.
